// La carte du comptoir. Les prix sont en centimes.
const menu = [
  { id: 1, name: "Espresso", category: "coffee", price: 220, available: true },
  { id: 2, name: "Noisette", category: "coffee", price: 250, available: true },
  { id: 3, name: "Allongé", category: "coffee", price: 260, available: true },
  { id: 4, name: "Cappuccino", category: "coffee", price: 380, available: true },
  { id: 5, name: "Flat white", category: "coffee", price: 400, available: true },
  { id: 6, name: "Latte", category: "coffee", price: 420, available: true },
  { id: 7, name: "Filtre V60", category: "coffee", price: 450, available: false },
  { id: 8, name: "Chocolat chaud", category: "tea", price: 420, available: true },
  { id: 9, name: "Chaï latte", category: "tea", price: 450, available: true },
  { id: 10, name: "Matcha latte", category: "tea", price: 480, available: true },
  { id: 11, name: "Thé vert sencha", category: "tea", price: 350, available: true },
  { id: 12, name: "Cookie pépites", category: "pastry", price: 280, available: true },
  { id: 13, name: "Cookie sésame", category: "pastry", price: 310, available: true },
  { id: 14, name: "Cookie peanut", category: "pastry", price: 320, available: false },
  { id: 15, name: "Carrot cake (part)", category: "pastry", price: 410, available: true },
  { id: 16, name: "Cinnamon roll", category: "pastry", price: 420, available: true },
];
