// Fournie : transforme 220 en "2,20 €". Tu n'as pas à la modifier.
function formatPrice(cents) {
  return (cents / 100).toFixed(2).replace(".", ",") + " €";
}


// Étape 1 · Afficher la carte

const indexMenu = menu.length;


function listeAll(event){

  event.preventDefault();
  const flagMenu = document.querySelector("#menu");
  flagMenu.replaceChildren();
  
  for (let i=0;i<indexMenu;i++){
    const produit = document.createElement("article");
    const flagCategory = document.createElement("span");
    const flagName = document.createElement("h3");
    const flagPrice = document.createElement("p");
    const flagBtn = document.createElement("button");

    produit.classList.add("product");

    const produitCategorie = menu[i].category;
    flagCategory.textContent = produitCategorie;
    flagCategory.classList.add("product-category");

    const produitName = menu[i].name;
    flagName.textContent =produitName;
    flagName.dataset.available=true
    flagName.classList.add("product-name");

    const produitPrix = formatPrice(Number(menu[i].price));
    flagPrice.textContent = produitPrix;
    flagPrice.classList.add("product-price");

    
    flagBtn.type="button";
    flagBtn.textContent ="ajouter";
    flagBtn.id=menu[i].id;
    flagBtn.classList.add("product-add");

    
    if (!menu[i].available){
      produit.classList.add("is-sold-out");
      flagBtn.disabled  = true;
    }

    flagMenu.appendChild(produit);
    produit.appendChild(flagCategory);
    produit.appendChild(flagName);
    produit.appendChild(flagPrice);
    produit.appendChild(flagBtn);
  }
}


function listeCafe(event){          
  
  
  event.preventDefault();
  const flagMenu = document.querySelector("#menu");
  flagMenu.replaceChildren();

  for (let i=0;i<indexMenu;i++){
    if (menu[i].category=="coffee"){
      const produit = document.createElement("article");
      const flagCategory = document.createElement("span");
      const flagName = document.createElement("h3");
      const flagPrice = document.createElement("p");
      const flagBtn = document.createElement("button");

      produit.classList.add("product");

      const produitCategorie = menu[i].category;
      flagCategory.textContent = produitCategorie;
      flagCategory.classList.add("product-category");

      const produitName = menu[i].name;
      flagName.textContent =produitName;
      flagName.dataset.available=true
      flagName.classList.add("product-name");

      const produitPrix = formatPrice(Number(menu[i].price));
      flagPrice.textContent = produitPrix;
      flagPrice.classList.add("product-price");

      flagBtn.type="button";
      flagBtn.textContent ="ajouter";
      flagBtn.id=menu[i].id;
      flagBtn.classList.add("product-add");

      
      if (!menu[i].available){
        produit.classList.add("is-sold-out");
        flagBtn.disabled  = true;
      }

      flagMenu.appendChild(produit);
      produit.appendChild(flagCategory);
      produit.appendChild(flagName);
      produit.appendChild(flagPrice);
      produit.appendChild(flagBtn);
    }
  }
} 

function listeThe(event){  

  
  event.preventDefault();
  const flagMenu = document.querySelector("#menu");
  flagMenu.replaceChildren();

  for (let i=0;i<indexMenu;i++){
    if (menu[i].category=="tea"){      const produit = document.createElement("article");
      const flagCategory = document.createElement("span");
      const flagName = document.createElement("h3");
      const flagPrice = document.createElement("p");
      const flagBtn = document.createElement("button");

      produit.classList.add("product");

      const produitCategorie = menu[i].category;
      flagCategory.textContent = produitCategorie;
      flagCategory.classList.add("product-category");

      const produitName = menu[i].name;
      flagName.textContent =produitName;
      flagName.dataset.available=true
      flagName.classList.add("product-name");

      const produitPrix = formatPrice(Number(menu[i].price));
      flagPrice.textContent = produitPrix;
      flagPrice.classList.add("product-price");

      flagBtn.type="button";
      flagBtn.textContent ="ajouter";
      flagBtn.id=menu[i].id;
      flagBtn.classList.add("product-add");


      if (!menu[i].available){
        produit.classList.add("is-sold-out");
        flagBtn.disabled  = true;
      }

      flagMenu.appendChild(produit);
      produit.appendChild(flagCategory);
      produit.appendChild(flagName);
      produit.appendChild(flagPrice);
      produit.appendChild(flagBtn);

    }
  }
} 

function listePatisserie(event){
  
  event.preventDefault();
  const flagMenu = document.querySelector("#menu");
  flagMenu.replaceChildren();

  for (let i=0;i<indexMenu;i++){
      if (menu[i].category=="pastry"){      
        const produit = document.createElement("article");
        const flagCategory = document.createElement("span");
        const flagName = document.createElement("h3");
        const flagPrice = document.createElement("p");
        const flagBtn = document.createElement("button");

        produit.classList.add("product");

        const produitCategorie = menu[i].category;
        flagCategory.textContent = produitCategorie;
        flagCategory.classList.add("product-category");

        const produitName = menu[i].name;
        flagName.textContent =produitName;  
        flagName.dataset.available = true;
        flagName.classList.add("product-name");

        const produitPrix = formatPrice(Number(menu[i].price));
        flagPrice.textContent = produitPrix;
        flagPrice.classList.add("product-price");

        flagBtn.type="button";
        flagBtn.textContent ="ajouter";
        flagBtn.id=menu[i].id;
        flagBtn.classList.add("product-add");

      
      if (!menu[i].available){
        produit.classList.add("is-sold-out");
        flagBtn.disabled  = true;
      }
      flagMenu.appendChild(produit);
      produit.appendChild(flagCategory);
      produit.appendChild(flagName);
      produit.appendChild(flagPrice);
      produit.appendChild(flagBtn);
    
    }
  }
} 


// const categorieBtn = document.querySelectorAll("button");
// for(let i=0;i<4;i++){
//   if(categorieBtn[i].value==="all"){
//     categorieBtn[i].addEventListener('click', listeAll);
//   }
//   else if(categorieBtn[i].value==="coffee"){
//     categorieBtn[i].addEventListener('click', listeCafe);
//   }
//   else if(categorieBtn[i].value==="tea"){
//     categorieBtn[i].addEventListener('click', listeThe);
//   }
//   else{
//     categorieBtn[i].addEventListener('click', listePatisserie);
//   }
// }

//const flagMenu = document.querySelector("#menu")


const affichages = {
  all: listeAll,
  coffee: listeCafe,
  tea: listeThe,
  pastry: listePatisserie,
};

const categorieBtn = document.querySelector("#categories");
categorieBtn.addEventListener("click",(event) => {
  const button = event.target.closest("button");
  if (!button) return;

  affichages[button.value](event);
});

// const categorieBtn = document.querySelectorAll("button");
// for(let i=0;i<4;i++){
//   if(categorieBtn[i].value==="all"){
//     categorieBtn[i].addEventListener('click',listeAll);
//   }
//   else if(categorieBtn[i].value==="coffee"){
//     categorieBtn[i].addEventListener('click', listeCafe);
//   }
//   else if(categorieBtn[i].value==="tea"){
//     categorieBtn[i].addEventListener('click', listeThe);
//   }
//   else{
//     categorieBtn[i].addEventListener('click', listePatisserie);
//   }
// }



// Étape 2 · Les produits épuisés
// function empty(event) {
//     event.preventDefault();
//     const btn = event.target.closest("product-add");
//     const 
//     if()

// }
// const flagBtn = document.querySelectorAll("#menu");
// flagBtn.addEventListener("click",empty);
// // )

//const flagMenu = document.querySelector("#menu");
//flagMenu.addEventListener('click',empty);

//
// Étape 3 · L'objet order
const order = {
  lines: [],

  add(product) {
    for (const line of this.lines) {
      if (line.id === product.id) {
        line.quantity++;
        return;
      }
    }
    this.lines.push({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
    });
  },

  remove(id) {
  for (let i = 0; i < this.lines.length; i++) {
    if (this.lines[i].id === id) {
      this.lines[i].quantity--;                 // on baisse de 1

      if (this.lines[i].quantity === 0) {
        this.lines.splice(i, 1);                // plus rien : on retire la ligne
      }
      return;                                   // trouvé, on s'arrête
    }
  }
},

  getSubtotal() {
    let total = 0;
    for (const line of this.lines) {
      total += line.price * line.quantity;
    }
    return total;
  },
};


// order.add(menu[3]);   // Cappuccino
// order.add(menu[3]);   // Cappuccino encore
// order.add(menu[12]);  // Cookie sésame
// for(let i=0;i<order.lines.length;i++){
//   console.log(order.lines[i]);
// }
//console.log(order.getSubtotal());   // 1070




// Étape 4 · Afficher le ticket


// function fullTicket (order){

//     const flagTicketFull = document.querySelector("#ticket-lines");
//     flagTicketFull.replaceChildren();
//     const flagMenu = document.querySelector("#menu");
//     const flagTicketLine = document.createElement("li");
//     const flagLineName = document.createElement("span");
//     const flagLineQty = document.createElement("span");
//     const flagLinePrice = document.createElement("span");
//     const flagBtn = document.createElement("button");

//     flagTicketLine.classList.add("ticket-line");

//     flagLineName.classList.add("line-name");
//     flagLineName.textContent = line.name;

//     flagLineQty.classList.add("line-qty");
//     flagLineQty.textContent=line.quantity;

//     flagLinePrice.classList.add("line-price");
//     flagLinePrice.textContent = formatPrice(Number(line.quantity) * Number(line.price));

//     flagBtn.type = "button";
//     flagBtn.classList.add("line-remove");
//     flagBtn.textContent = "−";
//     flagBtn.setAttribute("aria-label", `Retirer un ${line.name}`);
//     flagBtn .dataset.id = line.id;

//     flagTicketFull.appendChild(flagTicketLine);
//     flagTicketLine.appendChild(flagLineName);
//     flagTicketLine.appendChild(flagLineQty);
//     flagTicketLine.appendChild(flagLinePrice);
//     flagTicketLine.appendChild(flagBtn);
// };
function fullTicket (order){

    const flagTicketFull = document.querySelector("#ticket-lines");
    flagTicketFull.replaceChildren();
    for(let i=0;i<order.lines.length;i++){
      const flagMenu = document.querySelector("#menu");
      const flagTicketLine = document.createElement("li");
      const flagLineName = document.createElement("span");
      const flagLineQty = document.createElement("span");
      const flagLinePrice = document.createElement("span");
      const flagBtn = document.createElement("button");

      flagTicketLine.classList.add("ticket-line");

      flagLineName.classList.add("line-name");
      flagLineName.textContent = order.lines[i].name;

      flagLineQty.classList.add("line-qty");
      flagLineQty.textContent=order.lines[i].quantity;

      flagLinePrice.classList.add("line-price");
      const total = formatPrice(Number(order.lines[i].quantity) * Number(order.lines[i].price));
      flagLinePrice.textContent = total;

      flagBtn.type = "button";
      flagBtn.classList.add("line-remove");
      flagBtn.textContent = "−";
      flagBtn.setAttribute("aria-label", `Retirer un ${order.lines.name}`);
      flagBtn.id = order.lines[i].id;

      flagTicketFull.appendChild(flagTicketLine);
      flagTicketLine.appendChild(flagLineName);
      flagTicketLine.appendChild(flagLineQty);
      flagTicketLine.appendChild(flagLinePrice);
      flagTicketLine.appendChild(flagBtn);
    }
};








const flagMenu = document.querySelector("#menu");

flagMenu.addEventListener("click", (event) => {
  const button = event.target.closest(".product-add");
  if (!button) return;

  const product = menu.find((p) => p.id === Number(button.id));
  order.add(product);
  fullTicket(order);
});

const flagTicketLine = document.querySelector("#ticket-lines");
flagTicketLine.addEventListener("click",(event) => {
  const button = event.target.closest(".line-remove");
  if (!button) return;

  
  const product = menu.find((p) => p.id === Number(button.id));

  order.remove(product.id);
  fullTicket(order);
  
})



// Étape 5 · Retirer une ligne


// Étape 6 · Filtrer par catégorie


// Étape 7 · Le prénom du client


// Étape 8 · Le code promo


// Bonus
